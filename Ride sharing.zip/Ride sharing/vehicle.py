from abc import ABC
class Vehicale(ABC):
    speed ={
        'car':50,
        'bike':60,
        'cng':15
    }
    def __init__(self,vehicle_type,license_plate,rate) -> None:
        self.vehicle_type=vehicle_type
        self.license_plate=license_plate
        self.rate=rate
class Car(Vehicale):
    def __init__(self, vehicle_type, license_plate, rate) -> None:
        super().__init__(vehicle_type, license_plate, rate)
class Bike(Vehicale):
    def __init__(self, vehicle_type, license_plate, rate) -> None:
        super().__init__(vehicle_type, license_plate, rate)