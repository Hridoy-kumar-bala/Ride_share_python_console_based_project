from ride import Ride,RideRequest,Ridermatching,RideSharing;
from user import Rider,Driver
from vehicle import Car,Bike

niye_jou = RideSharing("niye jou")
rahim =Rider("Rahim uddin","rahim@gamil.com",1234,"dhak_bangla",1200)
ayon =Driver("Ayon Vhodro","ayon@gmail.com",2345,"seromoy")
niye_jou.add_rider(rahim)
niye_jou.add_drivers(ayon)
rahim.request_ride(niye_jou,"shonaganga","car")
ayon.reach_destination(rahim.current_ride)
rahim.show_current_ride()
# print(niye_jou)
